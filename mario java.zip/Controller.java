/*
NAME: DILLON HINES
DATE: 10/8/21
DESC: Working collisions, along with some of my own movement and animation features.
*/

import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;

class Controller implements ActionListener, MouseListener, KeyListener {
	// save starting locations for each new brick
	int x;
	int y;
	boolean editing = false;
	boolean pause = false;
	boolean questionBlock = false;
	boolean keyLeft;
	boolean keyRight;
	boolean keyUp;
	boolean keyDown;
	boolean keyS;
	boolean keySpace;
	boolean keyE;
	boolean keyP;
	Model model;
	View view;

	Controller(Model m) {
		model = m;
	}

	// button clicked, button go away
	public void actionPerformed(ActionEvent e) {
		view.removeButton();
	}

	void setView(View v) {
		view = v;
	}

	// this sets the start position for a new brick, adjusted for screen scroll
	public void mousePressed(MouseEvent e) {
		if (editing) {
			x = e.getX() + model.mario.x - model.mario.marioOffset;
			y = e.getY();
		}
	}

	// do stuff after mouse press (THESE ARE ALL METHODS)
	public void mouseReleased(MouseEvent e) {
		if (editing) {
			int w = e.getX() - model.mario.marioOffset;
			int h = e.getY();
			w += model.mario.x;
			if (h < y) {
				int temp = h;
				h = y;
				y = temp;
			}
			if (w < x) {
				int temp = w;
				w = x;
				x = temp;
			}
			if(!questionBlock)
				model.newBrick(x, y, w, h); // gives the width and height of the brick
			else
				model.CoinBrick(x, y, w, h);
		}
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}

	public void mouseClicked(MouseEvent e) {
	}

	// check for keyboard press
	public void keyPressed(KeyEvent e) {
		switch (e.getKeyCode()) {
		case KeyEvent.VK_RIGHT:
			keyRight = true;
			break;
		case KeyEvent.VK_LEFT:
			keyLeft = true;
			break;
		case KeyEvent.VK_UP:
			// get rid of these, save booleans like this in the controller and if they're
			// true then call functions to move mario
			model.mario.jumping = true;
			break;
		case KeyEvent.VK_SPACE:
			model.mario.jumping = true;
			break;
		case KeyEvent.VK_DOWN:
			keyDown = true;
			break; // WITHOUT THESE BREAK STATEMENTS, EVERY STATEMENT BELOW WILL RUN AS IF THOSE
					// CASES WERE TRUE
		case KeyEvent.VK_S:
			keyS = true;

			// Need to change this stuff so that the keyevents are changing booleans
			// that are being used in update() instead of calling functions immediately,
			// for the sake of smoothness

			if (editing) {
				model.marshal();
			}
			break;
		case KeyEvent.VK_L:
			if (editing) {
				model.load(Json.load("map.json"));
			}
			break;
		case KeyEvent.VK_E:
			if (editing) {
				editing = false;
			} else {
				editing = true;
			}
			break;
		case KeyEvent.VK_P:
			if (!pause) {
				pause = true;
			} else {
				pause = false;
			}
			break;
		case KeyEvent.VK_Q:
			if (!questionBlock) {
				questionBlock = true;
			} else {
				questionBlock = false;
			}
			break;
		}

	}

	// check for keyboard release
	public void keyReleased(KeyEvent e) {
		switch (e.getKeyCode()) {
		case KeyEvent.VK_RIGHT:
			keyRight = false;
			break;
		case KeyEvent.VK_LEFT:
			keyLeft = false;
			break;
		case KeyEvent.VK_UP:
			model.mario.jumping = false;
			break;
		case KeyEvent.VK_SPACE:
			model.mario.jumping = false;
			break;
		case KeyEvent.VK_DOWN:
			keyDown = false;
			break;
		}
	}

	public void keyTyped(KeyEvent e) {
	}

	// if keyboard press then move view
	void update() {
		// The booleans here are used for animation control in the view class
		// The ints being modified allow Mario to gradually speed up and slow down

		if (keyRight || keyLeft) {
			model.mario.stopped = false;
			if (keyRight) {
				model.mario.left = false;
				model.mario.horizontal_velocity += 5;
			}
			if (keyLeft) {
				model.mario.left = true;
				model.mario.horizontal_velocity -= 5;
			}
			// if(keyDown) model.dest_y++;
			// if(keyUp) model.dest_y--;
		} else {
			if (model.mario.horizontal_velocity < -3) {
				model.mario.horizontal_velocity += 3;
			} else if (model.mario.horizontal_velocity > 3) {
				model.mario.horizontal_velocity -= 3;
			} else {
				model.mario.stopped = true;
				model.mario.horizontal_velocity = 0;
			}
		}
	}
}
