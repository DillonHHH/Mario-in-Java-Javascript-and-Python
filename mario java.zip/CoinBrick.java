import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class CoinBrick extends Sprite {
	int coins = 5;
	boolean empty = false;
	static BufferedImage image = null;
	static BufferedImage emptyImage = null;
	Model model;

	boolean isCoinBrick() {
		return true;
	}

	public CoinBrick(int a, int b, int c, int d, Model m) {
		x = a;
		y = b;
		w = c;
		h = d;
		loadImage();
		model = m;
	}

	public CoinBrick(Brick b, Model m) {
		x = b.x;
		y = b.y;
		w = b.w;
		h = b.h;
		loadImage();
		model = m;
	}

	void loadImage() {
		try {
			image = ImageIO.read(new File("CoinBrick.png"));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		try {
			emptyImage = ImageIO.read(new File("EmptyCoinBrick.png"));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}

	@Override
	void draw(Graphics g) {
		if (empty)
			g.drawImage(emptyImage, x - model.mario.x + model.mario.marioOffset, y, w, h, null);
		else
			g.drawImage(image, x - model.mario.x + model.mario.marioOffset, y, w, h, null);
	}

	void bump() {
		if (!empty) {
			coins--;
			if (coins == 0) {
				empty = true;
			}
			model.sprites.add((Sprite) new Coin(x + w / 2, y, model));
			// call model spawn coin function here
		}
	}

	@Override
	void update() {

	}

}
