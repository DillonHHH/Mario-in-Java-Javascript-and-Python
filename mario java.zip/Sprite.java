import java.awt.image.BufferedImage;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

abstract class Sprite {
	// declare these in constructors
	int x, y, w, h;
	
	abstract void update();
	abstract void draw(Graphics g);

	boolean isBrick() {
		return false;
	}
	boolean isMario(){
		return false;
	}
	boolean isCoinBrick(){
		return false;
	}
}
