
/*
NAME: DILLON HINES
DATE: 10/8/21
DESC: Working collisions, along with some of my own movement and animation features.
*/
import java.util.ArrayList;
import java.util.Iterator;

class Model {
	ArrayList<Sprite> sprites;
	Mario mario;

	Model() {
		sprites = new ArrayList<Sprite>();
		mario = new Mario();
		sprites.add(mario);
	}

	public void newBrick(int startingX, int startingY, int finalX, int finalY) {
		sprites.add(new Brick(startingX, startingY, finalX - startingX, finalY - startingY, this));
	}

	public void CoinBrick(int startingX, int startingY, int finalX, int finalY) {
		sprites.add(new CoinBrick(startingX, startingY, finalX - startingX, finalY - startingY, this));
	}

	public void load(Json ob) {
		sprites.clear();
		sprites.add(mario);
		Json tmpList = ob.get("bricks");
		for (int i = 0; i < tmpList.size(); i++) {
			sprites.add(new Brick(tmpList.get(i), this));
		}
		for (int i = 0; i < sprites.size(); i++) {
			Sprite sprite = sprites.get(i);
			if(sprite.isBrick()) {
				if(Math.random() * 2 < 1);
					sprites.set(i, new CoinBrick((Brick)sprites.get(i), this));
			}
		}
	}

	public void loadDefault() {
		sprites.clear();
		sprites.add(mario);
		Json tmpList = Json.load("default_Map.json").get("bricks");
		for (int i = 0; i < tmpList.size(); i++) {
			sprites.add(new Brick(tmpList.get(i), this));
		}
		for (int i = 0; i < sprites.size(); i++) {
			Sprite sprite = sprites.get(i);
			if(sprite.isBrick()) {
				if(Math.random() * 2 < 1)
					sprites.set(i, new CoinBrick((Brick)sprite, this));
			}
		}
	}

	Json marshal() {
		Json modelOb = Json.newObject();
		Json brickList = Json.newList();
		modelOb.add("bricks", brickList);
		Iterator<Sprite> it = sprites.iterator();
		while (it.hasNext()) {
			Sprite sprite = it.next();
			if (sprite.isBrick())
				brickList.add(((Brick) sprite).marshal());
		}
		modelOb.save("map.json");
		return modelOb;
	}

	public void update() {
		for (int i = 0; i < sprites.size(); i++) {
			sprites.get(i).update();
		}
		for (int i = 0; i < sprites.size(); i++) {
			Sprite sprite = sprites.get(i);
			if (!sprite.isMario()) {
				if (collision(sprite)) {
					// System.out.println("mario: " + mario.x + " " + mario.y + " "+ mario.prevx + "
					// " + mario.prevy + "\nbrick: " + brick.x + " " + brick.y + " " + brick.w + " "
					// + brick.h); //test script
					//left
					if (mario.x + 60 > sprite.x && mario.prevx + 60 <= sprite.x) {
						mario.horizontal_velocity = 0;
						mario.x = sprite.x - 60;
						//right
					} else if (mario.x < sprite.x + sprite.w && mario.prevx >= sprite.x + sprite.w) {
						mario.horizontal_velocity = 0;
						mario.x = sprite.x + sprite.w;
						//feet
					} else if (mario.y + 95 > sprite.y && mario.prevy + 95 <= sprite.y) {
						mario.jump_counter = 0;
						mario.vertical_velocity = 0;
						mario.y = sprite.y - 95;
						//head
					} else if (mario.y < sprite.y + sprite.h && mario.prevy >= sprite.y + sprite.h) {
						mario.vertical_velocity = 0;
						mario.y = sprite.y + sprite.h;
						if(sprite.isCoinBrick()) {
							((CoinBrick)sprite).bump();
						}
						
					}
				}

			}
		}
	}

	public boolean collision(Sprite  sprite) {

		if (mario.x + 60 < sprite.x) {
			return false;
		}
		if (mario.x > sprite.x + sprite.w) {
			return false;
		}
		if (mario.y + 95 < sprite.y) {
			return false;
		}
		if (mario.y > sprite.y + sprite.h) {
			return false;
		}
		return true;
	}

}