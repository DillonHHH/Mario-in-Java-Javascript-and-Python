import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Coin extends Sprite{
	
	static BufferedImage image = null;
	Model model;
	double vertical_velocity = -20, horizontal_velocity = Math.random()*25;
	
	public Coin(int a, int b, Model m) {
		x = a;
		y = b;
		w = 20;
		h = 20;
		loadImage();
		model = m;
	}
	
	
	void loadImage() {
		try {
			image = ImageIO.read(new File("Coin.png"));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	@Override
	void update() {
		vertical_velocity += 3;
		y += vertical_velocity;
		x += horizontal_velocity;
		if(y > 1500)
			for (int i = 0; i < model.sprites.size(); i++) {
				if (model.sprites.get(i) == this)
					model.sprites.remove(i);
			}
	}

	@Override
	void draw(Graphics g) {
		g.drawImage(image, x - model.mario.x + model.mario.marioOffset, y, w, h, null);
	}
	

}
