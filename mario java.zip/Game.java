
/*
NAME: DILLON HINES
DATE: 10/8/21
DESC: Working collisions, along with some of my own movement and animation features.
*/
import javax.swing.JFrame;
import java.awt.Toolkit;

public class Game extends JFrame {
	// model is passed to controller and view so that they can reference later
	// these variables can't be declared in the constructor or else they can't be
	// used in the other methods
	Model model = new Model();
	Controller controller = new Controller(model);
	View view = new View(controller, model);

	public Game() {
		this.setTitle("A4 - Mario"); // title of the window
		this.setSize(1200, 800); // Size of window
		this.setFocusable(true);
		this.getContentPane().add(view);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		view.addMouseListener(controller); // tells the program that the mouse is handled by controller
		this.addKeyListener(controller); // tells the program that the keyboard is handled by controller
	}

	public static void main(String[] args) {
		Game g = new Game();
		g.run(); // starts the screen refreshing method below
	}

	public void run() {
		while (true) {
			if (!controller.pause) {
				// controller.update();
				model.update();
				view.repaint(); // Indirectly calls View.paintComponent
				controller.update(); // without this the arrow keys won't be detected
				Toolkit.getDefaultToolkit().sync(); // Updates screen
			}
			// Go to sleep for 50 milliseconds
			try {
				Thread.sleep(50); // 1000ms / 50ms = 20 - 20fps
			} catch (Exception e) {
				e.printStackTrace();
				System.exit(1);
			}
		}
	}

}
