
/*
NAME: DILLON HINES
DATE: 10/8/21
DESC: Working collisions, along with some of my own movement and animation features.
*/
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

class Brick extends Sprite {
	// need to make sure I don't have duplicate variables, xywh should be moved to
	// sprite
	// also applied to mario
	static BufferedImage image = null;
	Model model;

	public Brick(int a, int b, int c, int d, Model m) {
		x = a;
		y = b;
		w = c;
		h = d;
		marshal();
		loadImage();
		model = m;
	}

	public Brick(Json ob, Model m) {
		x = (int) ob.getLong("x");
		y = (int) ob.getLong("y");
		w = (int) ob.getLong("w");
		h = (int) ob.getLong("h");
		loadImage();
		model = m;
	}

	Json marshal() {
		Json brickOb = Json.newObject();
		brickOb.add("x", x);
		brickOb.add("y", y);
		brickOb.add("w", w);
		brickOb.add("h", h);
		return brickOb;
	}

	void loadImage() {
		try {
			image = ImageIO.read(new File("brick.png"));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}

	@Override
	boolean isBrick() {
		return true;
	}

	@Override
	void update() {

	}

	@Override
	void draw(Graphics g) {
		g.drawImage(image, x - model.mario.x + model.mario.marioOffset, y, w, h, null);
	}

}
