
/*
NAME: DILLON HINES
DATE: 10/8/21
DESC: Working collisions, along with some of my own movement and animation features.
*/
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.imageio.ImageIO;

// mario needs to extend sprite class
class Mario extends Sprite {
	static BufferedImage[] marioIcons = null;
	int marioOffset = 250;
	int prevx, prevy;
	double vertical_velocity, horizontal_velocity;
	int jump_counter = 0;
	boolean jumping = false;
	boolean left = false;
	boolean stopped = true;
	int marioState = 2;

	public Mario() {
		marioIcons = new BufferedImage[5];
		for (int i = 0; i < 5; i++) {
			System.out.println("mario" + String.valueOf(i + 1) + ".png");
			try {
				marioIcons[i] = ImageIO.read(new File("mario" + String.valueOf(i + 1) + ".png"));
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		x = 200;
		y = 200;
		vertical_velocity = 0;
		horizontal_velocity = 0;
	}

	// save mario's previous coords and compare to new coords to check which
	// direction collision came from
	// collision detection and all mario related coord changes need to be moved to
	// Mario class

	// MAKE SURE MARIO IS ALWAYS DOING THE COLLISION DETECTION

	public void update() {
		prevx = x;
		prevy = y;

		if (!stopped && jump_counter == 0)
			if (marioState < 4)
				marioState++;
			else
				marioState = 0;

		if (y >= 500 && jump_counter != 1) {
			jump_counter = 0;
			vertical_velocity = 0.0;
			y = 500; // snap back to the ground
		} else if ((y != 500 || vertical_velocity < 0) && (!jumping || jump_counter >= 5)) {
			jump_counter = 5;
			vertical_velocity += 3.5; // gravity
			y += vertical_velocity; // update position
		} else {
			y += vertical_velocity;
		}
		if (horizontal_velocity > 20) {
			horizontal_velocity = 20;
		} else if (horizontal_velocity < -20) {
			horizontal_velocity = -20;
		}
		x += horizontal_velocity;

		if (jumping && jump_counter < 5) {
			jump_counter++;
			vertical_velocity -= 8;
		}
		if (y > 500)
			y = 500;

	}

	@Override
	boolean isMario() {
		return true;
	}

	@Override
	void draw(Graphics g) {
		if (!left)
			g.drawImage(Mario.marioIcons[marioState], 250, y, 60, 95, null);
		else
			g.drawImage(Mario.marioIcons[marioState], 250 + 60, y, -60, 95, null);

	}

}