/*
NAME: DILLON HINES
DATE: 10/8/21
DESC: Working collisions, along with some of my own movement and animation features.
*/

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.util.ArrayList;
import java.io.File;
import javax.swing.JButton;
import java.awt.Color;

class View extends JPanel {
	// gotta declare model separately in a few classes in order to reference later,
	// it is given to us in the constructor
	Model model;
	BufferedImage background;
	BufferedImage ground;
	
	View(Controller c, Model m) {
		c.setView(this);
		model = m;
		m.loadDefault();
		try {
			this.background = ImageIO.read(new File("background.jpg"));
		} catch (Exception e) {
			e.printStackTrace(System.err);
			System.exit(1);
		}
		try {
			this.ground = ImageIO.read(new File("ground.jpg"));
		} catch (Exception e) {
			e.printStackTrace(System.err);
			System.exit(1);
		}
	}

	void removeButton() {
		this.repaint();
	}

	public void paintComponent(Graphics g) {
		g.setColor(new Color(128, 255, 255));
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		g.drawImage(background, model.mario.x / -8 - 100, 0, 1920, 1080, null);
		g.drawLine(0, 596, 2000, 596);
		g.drawImage(ground, model.mario.x * -1 - 100, 596, 1920, 500, null);
		for (int i = 0; i < model.sprites.size(); i++) 
			model.sprites.get(i).draw(g);
		g.setColor(Color.gray);
	}
}
